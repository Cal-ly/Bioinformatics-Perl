#!/usr/bin/Perl

#This script writes the number 1 to 10 on the screen

$i = 1;			#Our integer statement 
while ($i <= 10){	#Our condition: as long as $i is less or eq to 10 the 
	print "$i\n";	#loop will run and print $i on the screen
	$i += 1;	#adds 1 to $i for every loop
};

