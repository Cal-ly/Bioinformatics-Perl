#!/usr/bin/perl

# This script printes "Hello world!" on the screen

print 'Hello world!';	#The print statement, "printes" the writen text on the 
			#on the screen
